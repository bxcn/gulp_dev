"use strict";/**123**/
!function(){function t(){var t=$(".bg");this.show=function(n){t.show(),$(n).show()},this.hide=function(n){t.hide(),$(n).hide()}}window.layoutDialog=new t}(),$(function(){function t(){function t(t){return t<10&&(t="0"+t),t}var n=$("#hint"),i=null;return{yaoqing:function(e){var a=this;n.html("本次邀请将在24小时00分00秒后到期"),i=window.setInterval(function(){if(e<1e3)return window.clearInterval(i),i=null,a.guoqi(),layoutDialog.hide(".jieshou"),void layoutDialog.hide(".select_no_hobby");var o=parseInt(e/1e3/60/60%24,10),l=parseInt(e/1e3/60%60,10),c=parseInt(e/1e3%60,10);//计算剩余的秒数
o=t(o),l=t(l),c=t(c),n.html("本次邀请将在"+o+"小时"+l+"分"+c+"秒后到期"),e-=1e3},1e3)},guoqi:function(){window.clearInterval(i),n.html("本次邀请已过期失效（有效期24小时）").attr("class","hint bg_gray")},jujue:function(){window.clearInterval(i),n.html("您已经拒绝本次邀请").attr("class","hint bg_red")},jieshou:function(){window.clearInterval(i),n.html("您已经接受本次邀请").attr("class","hint bg_green")}}}
// 展开查看更多职位和企业资料
$('[data-bind="extend_open_btn"]').click(function(){$(".tab").css({height:"auto"}),$(".extend >.btn").eq(0).hide(),$(".extend >.btn").eq(1).show()}),
// 关闭查看更多职位和企业资料
$('[data-bind="extend_close_btn"]').click(function(){$(".tab").css({height:"200px"}),$(".extend >.btn").eq(1).hide(),$(".extend >.btn").eq(0).show()}).hide(),
// 不感兴趣事件
$('[data-bind="no_hobby"]').click(function(){layoutDialog.show(".select_no_hobby")}),
// 接受邀请事件
$('[data-bind="hobby"]').click(function(){layoutDialog.show(".accept_shade"),$(window).scrollTop(0)}),
// 我知道了
$('[data-bind="accept"]').click(function(){layoutDialog.hide(".accept_shade"),hintState.jieshou(),layoutDialog.hide(".jieshou")}),
// 不感兴趣列表中的取消事件
$('[data-bind="select_cancel"]').click(function(){layoutDialog.hide(".select_no_hobby")}),
// 不感兴趣列中选择后的事件
$('[data-bind="selected"]').click(function(){layoutDialog.hide(".select_no_hobby"),layoutDialog.hide(".jieshou"),hintState.jujue()}),window.hintState=t(),hintState.yaoqing(5183999e3),$(".tab_nav").find("li").click(function(){var t=$(this),n=$(".tab_nav").find("li").index(t);$(".tab_nav").find("li").removeClass("curr"),t.addClass("curr"),$(".tab_list").find("li").hide(),$(".tab_list").find("li").eq(n).show()})});